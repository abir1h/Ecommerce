package com.shekarmudaliyar.social_share

import androidx.core.content.FileProvider

class SocialSharePluginFileProvider : FileProvider()