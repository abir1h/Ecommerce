package app.bigzbe.com

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
